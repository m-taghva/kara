************
Getting help
************

.. note::
   For information on how to connect with Pywikibot developers and users, see :manpage:`Communication`.

.. tip::
   Please report bugs in `Phabricator <https://phabricator.wikimedia.org/>`_.
   You can use `this report form <https://phabricator.wikimedia.org/maniphest/task/edit/form/1/?tags=pywikibot-core>`_.
