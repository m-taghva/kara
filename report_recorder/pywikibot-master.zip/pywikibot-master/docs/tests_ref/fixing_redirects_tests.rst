*************************************
tests.fixing\_redirects\_tests module
*************************************

.. automodule:: tests.fixing_redirects_tests
    :members:
    :undoc-members:
    :show-inheritance:
