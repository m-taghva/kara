**********************************
tests.pagegenerators\_tests module
**********************************

.. automodule:: tests.pagegenerators_tests
    :members:
    :undoc-members:
    :show-inheritance:
