*************************
tests.setup\_tests module
*************************

.. automodule:: tests.setup_tests
    :members:
    :undoc-members:
    :show-inheritance:
