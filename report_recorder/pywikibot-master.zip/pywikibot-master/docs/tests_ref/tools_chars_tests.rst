********************************
tests.tools\_chars\_tests module
********************************

.. automodule:: tests.tools_chars_tests
    :members:
    :undoc-members:
    :show-inheritance:
