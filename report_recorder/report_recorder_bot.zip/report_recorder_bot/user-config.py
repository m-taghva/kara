mylang = 'fa'
family = 'kateb'
usernames['kateb']['fa'] = 'user name'
console_encoding = 'utf-8'
