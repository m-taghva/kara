"""Dummy package initialisation."""

from __future__ import annotations
