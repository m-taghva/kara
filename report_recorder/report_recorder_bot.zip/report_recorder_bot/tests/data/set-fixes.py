"""Fixes implementation which overwrites the variable."""
#
# (C) Pywikibot team, 2015-2023
#
# Distributed under the terms of the MIT license.
#
from __future__ import annotations


# Just kill the old value suffices
fixes = {}
