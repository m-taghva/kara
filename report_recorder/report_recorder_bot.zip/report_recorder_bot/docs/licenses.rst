:tocdepth: 1

********
Licenses
********

**The framework itself and this documentation** are available under the
:ref:`MIT license`; translations by translators and manual pages on
mediawiki.org are available under the `CC-BY-SA 3.0`_ license. The
Pywikibot logo is Public domain but it includes material that may be
protected as a trademark. Parts of :mod:`memento<data.memento>`
module is licenced under the `BSD`_ open source software license. You
may obtain a copy of the License at
http://mementoweb.github.io/SiteStory/license.html.


MIT License
===========
**The framework is available under the MIT license.**

.. include:: ../LICENSE


.. _CC-BY-SA 3.0: https://creativecommons.org/licenses/by-sa/3.0/
.. _BSD: https://github.com/mementoweb/py-memento-client/blob/master/LICENSE.txt
