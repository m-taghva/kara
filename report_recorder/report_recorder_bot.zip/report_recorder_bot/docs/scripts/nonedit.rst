*******************
Non editing scripts
*******************

listpages script
================

.. automodule:: scripts.listpages
   :no-members:
   :noindex:

touch script
============

.. automodule:: scripts.touch
   :no-members:
   :noindex:
