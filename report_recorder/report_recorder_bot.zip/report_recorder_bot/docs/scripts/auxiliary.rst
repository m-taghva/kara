*****************
Auxiliary scripts
*****************

clean\_sandbox script
=====================

.. automodule:: scripts.clean_sandbox
   :no-members:
   :noindex:

cosmetic\_changes script
========================

.. automodule:: scripts.cosmetic_changes
   :no-members:
   :noindex:

transferbot script
==================

.. automodule:: scripts.transferbot
   :no-members:
   :noindex:

transwikiimport script
======================

.. automodule:: scripts.transwikiimport
   :no-members:
   :noindex:
