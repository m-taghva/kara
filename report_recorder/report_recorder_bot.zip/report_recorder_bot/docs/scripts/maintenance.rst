***************
Utility scripts
***************

cache script
============

.. automodule:: scripts.maintenance.cache
   :no-members:
   :noindex:

colors script
=============

.. automodule:: scripts.maintenance.colors
   :no-members:
   :noindex:

make\_i18n\_dict script
=======================

.. automodule:: scripts.maintenance.make_i18n_dict
   :no-members:
   :noindex:

unidata script
==============

.. automodule:: scripts.maintenance.unidata
   :no-members:
   :noindex:

wikimedia\_sites script
=======================

.. automodule:: scripts.maintenance.wikimedia_sites
   :no-members:
   :noindex:
