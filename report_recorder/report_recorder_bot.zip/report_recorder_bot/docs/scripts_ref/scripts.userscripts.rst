**********************************
User scripts - scripts.userscripts
**********************************

.. automodule:: scripts.userscripts
