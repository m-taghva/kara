Global options
--------------

Global arguments available for all bots:

.. literalinclude:: ../pywikibot/bot.py
   :language: text
   :start-after: (Global arguments available for all bots)
   :end-before: """
