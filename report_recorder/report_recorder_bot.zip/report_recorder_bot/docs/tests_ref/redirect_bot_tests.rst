*********************************
tests.redirect\_bot\_tests module
*********************************

.. automodule:: tests.redirect_bot_tests
    :members:
    :undoc-members:
    :show-inheritance:
