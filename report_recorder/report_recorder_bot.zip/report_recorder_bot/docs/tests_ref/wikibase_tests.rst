****************************
tests.wikibase\_tests module
****************************

.. automodule:: tests.wikibase_tests
    :members:
    :undoc-members:
    :show-inheritance:
