************************************
tests.site\_generators\_tests module
************************************

.. automodule:: tests.site_generators_tests
    :members:
    :undoc-members:
    :show-inheritance:
