**************************
tests.sparql\_tests module
**************************

.. automodule:: tests.sparql_tests
    :members:
    :undoc-members:
    :show-inheritance:
