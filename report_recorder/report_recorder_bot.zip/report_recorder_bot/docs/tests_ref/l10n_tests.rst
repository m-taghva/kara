************************
tests.l10n\_tests module
************************

.. automodule:: tests.l10n_tests
    :members:
    :undoc-members:
    :show-inheritance:
