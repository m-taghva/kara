**********************************
tests.wikibase\_edit\_tests module
**********************************

.. automodule:: tests.wikibase_edit_tests
    :members:
    :undoc-members:
    :show-inheritance:
