*******************************
tests.checkimages\_tests module
*******************************

.. automodule:: tests.checkimages_tests
    :members:
    :undoc-members:
    :show-inheritance:
