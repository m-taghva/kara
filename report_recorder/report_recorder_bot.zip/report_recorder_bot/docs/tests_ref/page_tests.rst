************************
tests.page\_tests module
************************

.. automodule:: tests.page_tests
    :members:
    :undoc-members:
    :show-inheritance:
