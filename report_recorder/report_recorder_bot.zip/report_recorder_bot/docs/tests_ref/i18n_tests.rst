************************
tests.i18n\_tests module
************************

.. automodule:: tests.i18n_tests
    :members:
    :undoc-members:
    :show-inheritance:
