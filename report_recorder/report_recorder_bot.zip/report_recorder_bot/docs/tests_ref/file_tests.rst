************************
tests.file\_tests module
************************

.. automodule:: tests.file_tests
    :members:
    :undoc-members:
    :show-inheritance:
