**********************
tests.ui\_tests module
**********************

.. automodule:: tests.ui_tests
    :members:
    :undoc-members:
    :show-inheritance:
