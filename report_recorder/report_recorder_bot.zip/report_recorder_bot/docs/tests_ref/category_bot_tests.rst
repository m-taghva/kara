*********************************
tests.category\_bot\_tests module
*********************************

.. automodule:: tests.category_bot_tests
    :members:
    :undoc-members:
    :show-inheritance:
