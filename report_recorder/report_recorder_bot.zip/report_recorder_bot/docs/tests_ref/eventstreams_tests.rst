********************************
tests.eventstreams\_tests module
********************************

.. automodule:: tests.eventstreams_tests
    :members:
    :undoc-members:
    :show-inheritance:
