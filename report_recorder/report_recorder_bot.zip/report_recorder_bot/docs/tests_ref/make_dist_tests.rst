******************************
tests.make\_dist\_tests module
******************************

.. automodule:: tests.make_dist_tests
    :members:
    :undoc-members:
    :show-inheritance:
