******************************
tests.pwb.print\_locals module
******************************

.. automodule:: tests.pwb.print_locals
    :members:
    :undoc-members:
    :show-inheritance:
