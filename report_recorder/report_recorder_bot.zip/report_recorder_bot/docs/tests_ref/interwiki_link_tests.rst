***********************************
tests.interwiki\_link\_tests module
***********************************

.. automodule:: tests.interwiki_link_tests
    :members:
    :undoc-members:
    :show-inheritance:
