***********************
tests.bot\_tests module
***********************

.. automodule:: tests.bot_tests
    :members:
    :undoc-members:
    :show-inheritance:
