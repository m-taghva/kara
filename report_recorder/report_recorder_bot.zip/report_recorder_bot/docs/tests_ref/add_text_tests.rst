*****************************
tests.add\_text\_tests module
*****************************

.. automodule:: tests.add_text_tests
    :members:
    :undoc-members:
    :show-inheritance:
