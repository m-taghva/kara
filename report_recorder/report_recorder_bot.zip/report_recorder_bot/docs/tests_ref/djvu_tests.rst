************************
tests.djvu\_tests module
************************

.. automodule:: tests.djvu_tests
    :members:
    :undoc-members:
    :show-inheritance:
