*********************************
tests.interwikidata\_tests module
*********************************

.. automodule:: tests.interwikidata_tests
    :members:
    :undoc-members:
    :show-inheritance:
