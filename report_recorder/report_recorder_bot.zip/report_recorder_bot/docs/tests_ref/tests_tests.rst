*************************
tests.tests\_tests module
*************************

.. automodule:: tests.tests_tests
    :members:
    :undoc-members:
    :show-inheritance:
