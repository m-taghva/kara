****************************
tests.category\_tests module
****************************

.. automodule:: tests.category_tests
    :members:
    :undoc-members:
    :show-inheritance:
