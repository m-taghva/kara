******************************
tests.replacebot\_tests module
******************************

.. automodule:: tests.replacebot_tests
    :members:
    :undoc-members:
    :show-inheritance:
