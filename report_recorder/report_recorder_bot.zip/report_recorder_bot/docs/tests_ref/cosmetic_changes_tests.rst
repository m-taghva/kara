*************************************
tests.cosmetic\_changes\_tests module
*************************************

.. automodule:: tests.cosmetic_changes_tests
    :members:
    :undoc-members:
    :show-inheritance:
