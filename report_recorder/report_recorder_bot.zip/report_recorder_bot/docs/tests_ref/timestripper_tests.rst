********************************
tests.timestripper\_tests module
********************************

.. automodule:: tests.timestripper_tests
    :members:
    :undoc-members:
    :show-inheritance:
