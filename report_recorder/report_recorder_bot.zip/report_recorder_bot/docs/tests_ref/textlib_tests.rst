***************************
tests.textlib\_tests module
***************************

.. automodule:: tests.textlib_tests
    :members:
    :undoc-members:
    :show-inheritance:
