******************************
tests.logentries\_tests module
******************************

.. automodule:: tests.logentries_tests
    :members:
    :undoc-members:
    :show-inheritance:
