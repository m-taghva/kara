*********************************
tests.template\_bot\_tests module
*********************************

.. automodule:: tests.template_bot_tests
    :members:
    :undoc-members:
    :show-inheritance:
