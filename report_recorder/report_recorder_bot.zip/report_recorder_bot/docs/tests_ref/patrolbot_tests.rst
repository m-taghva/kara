*****************************
tests.patrolbot\_tests module
*****************************

.. automodule:: tests.patrolbot_tests
    :members:
    :undoc-members:
    :show-inheritance:
