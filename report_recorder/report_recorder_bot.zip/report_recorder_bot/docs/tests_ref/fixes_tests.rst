*************************
tests.fixes\_tests module
*************************

.. automodule:: tests.fixes_tests
    :members:
    :undoc-members:
    :show-inheritance:
