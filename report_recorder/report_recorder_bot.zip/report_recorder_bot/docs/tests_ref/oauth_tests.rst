*************************
tests.oauth\_tests module
*************************

.. automodule:: tests.oauth_tests
    :members:
    :undoc-members:
    :show-inheritance:
