************************
tests.user\_tests module
************************

.. automodule:: tests.user_tests
    :members:
    :undoc-members:
    :show-inheritance:
