*******************************
tests.deletionbot\_tests module
*******************************

.. automodule:: tests.deletionbot_tests
    :members:
    :undoc-members:
    :show-inheritance:
