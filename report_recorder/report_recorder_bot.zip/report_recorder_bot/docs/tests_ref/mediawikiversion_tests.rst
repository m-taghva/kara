************************************
tests.mediawikiversion\_tests module
************************************

.. automodule:: tests.mediawikiversion_tests
    :members:
    :undoc-members:
    :show-inheritance:
