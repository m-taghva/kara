***********************
tests.gui\_tests module
***********************

.. automodule:: tests.gui_tests
    :members:
    :undoc-members:
    :show-inheritance:
