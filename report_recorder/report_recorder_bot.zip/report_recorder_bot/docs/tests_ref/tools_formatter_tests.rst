************************************
tests.tools\_formatter\_tests module
************************************

.. automodule:: tests.tools_formatter_tests
    :members:
    :undoc-members:
    :show-inheritance:
