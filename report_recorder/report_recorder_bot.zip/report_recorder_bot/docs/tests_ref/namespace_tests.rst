*****************************
tests.namespace\_tests module
*****************************

.. automodule:: tests.namespace_tests
    :members:
    :undoc-members:
    :show-inheritance:
