************************
tests.site\_tests module
************************

.. automodule:: tests.site_tests
    :members:
    :undoc-members:
    :show-inheritance:
