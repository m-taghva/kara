************************
tests.edit\_tests module
************************

.. automodule:: tests.edit_tests
    :members:
    :undoc-members:
    :show-inheritance:
