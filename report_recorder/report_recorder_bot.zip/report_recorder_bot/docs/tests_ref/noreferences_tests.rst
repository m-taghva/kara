********************************
tests.noreferences\_tests module
********************************

.. automodule:: tests.noreferences_tests
    :members:
    :undoc-members:
    :show-inheritance:
