****************************************
:mod:`bot` --- Classes for Building Bots
****************************************

.. automodule:: bot
   :synopsis: User-interface related functions for building bots
   :member-order: bysource
