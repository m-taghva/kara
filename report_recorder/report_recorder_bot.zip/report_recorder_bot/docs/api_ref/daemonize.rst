**********************************************************
:mod:`daemonize` --- Daemonize Current Process (Unix only)
**********************************************************

.. automodule:: daemonize
   :synopsis: Module to daemonize the current process on Unix.
