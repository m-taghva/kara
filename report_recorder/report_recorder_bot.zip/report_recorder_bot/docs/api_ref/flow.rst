*****************************
:mod:`flow` --- Flow Entities
*****************************

.. automodule:: flow
   :synopsis: Objects representing Flow entities, like boards, topics, and posts
