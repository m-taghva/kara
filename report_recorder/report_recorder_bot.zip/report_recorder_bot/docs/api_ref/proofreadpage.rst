************************************************
:mod:`proofreadpage` --- ProofreadPage Extension
************************************************

.. automodule:: proofreadpage
   :synopsis: Objects used with ProofreadPage Extension
