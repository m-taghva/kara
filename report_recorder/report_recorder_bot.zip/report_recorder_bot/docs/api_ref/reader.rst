*******************************
:mod:`xmlreader` --- XML Reader
*******************************

.. automodule:: xmlreader
   :synopsis: XML reading module
