**********
Change log
**********

What is new with Pywikibot |release|? What are the main changes of older version?

Roadmap
=======

.. include:: ../ROADMAP.rst

.. include:: ../HISTORY.rst
