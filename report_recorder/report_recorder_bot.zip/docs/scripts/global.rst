******************
Global bot scripts
******************

interwiki script
================

Creates or modifies Interlanguage links between projects.

.. automodule:: scripts.interwiki
   :no-members:
   :noindex:

redirect script
===============

.. automodule:: scripts.redirect
   :no-members:
   :noindex:
