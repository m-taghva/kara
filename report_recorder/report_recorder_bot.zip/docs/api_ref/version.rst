**********************************************
:mod:`version` --- Determine Pywikibot Version
**********************************************

.. automodule:: version
   :synopsis: Module to determine the pywikibot version (tag, revision and date)
