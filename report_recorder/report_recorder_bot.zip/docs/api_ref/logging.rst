.. module:: logging
   :synopsis: User output/logging functions

************************************
:mod:`logging` --- Logging Functions
************************************

.. automodule:: pywikibot.logging
   :member-order: bysource
