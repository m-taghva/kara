***********************************************
:mod:`pywikibot` --- Base Classes and Functions
***********************************************

.. automodule:: pywikibot
