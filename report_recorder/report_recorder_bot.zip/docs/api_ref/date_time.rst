******************************************
:mod:`time` --- Time Classes and Functions
******************************************

.. automodule:: pywikibot.time
