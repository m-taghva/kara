**************************
tests.thanks\_tests module
**************************

.. automodule:: tests.thanks_tests
    :members:
    :undoc-members:
    :show-inheritance:
