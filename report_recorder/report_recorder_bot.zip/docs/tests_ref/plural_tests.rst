**************************
tests.plural\_tests module
**************************

.. automodule:: tests.plural_tests
    :members:
    :undoc-members:
    :show-inheritance:
