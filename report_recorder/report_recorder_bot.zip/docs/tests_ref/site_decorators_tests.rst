************************************
tests.site\_decorators\_tests module
************************************

.. automodule:: tests.site_decorators_tests
    :members:
    :undoc-members:
    :show-inheritance:
