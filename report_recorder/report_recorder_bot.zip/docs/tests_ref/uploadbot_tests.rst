*****************************
tests.uploadbot\_tests module
*****************************

.. automodule:: tests.uploadbot_tests
    :members:
    :undoc-members:
    :show-inheritance:
