************************************
tests.tools\_deprecate\_tests module
************************************

.. automodule:: tests.tools_deprecate_tests
    :members:
    :undoc-members:
    :show-inheritance:
