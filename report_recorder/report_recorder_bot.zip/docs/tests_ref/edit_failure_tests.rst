*********************************
tests.edit\_failure\_tests module
*********************************

.. automodule:: tests.edit_failure_tests
    :members:
    :undoc-members:
    :show-inheritance:
