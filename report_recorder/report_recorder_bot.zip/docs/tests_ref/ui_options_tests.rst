*******************************
tests.ui\_options\_tests module
*******************************

.. automodule:: tests.ui_options_tests
    :members:
    :undoc-members:
    :show-inheritance:
