********************************
tests.flow\_thanks\_tests module
********************************

.. automodule:: tests.flow_thanks_tests
    :members:
    :undoc-members:
    :show-inheritance:
