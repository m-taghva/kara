*****************************
tests.wikistats\_tests module
*****************************

.. automodule:: tests.wikistats_tests
    :members:
    :undoc-members:
    :show-inheritance:
