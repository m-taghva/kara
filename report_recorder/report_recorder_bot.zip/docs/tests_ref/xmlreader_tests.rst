*****************************
tests.xmlreader\_tests module
*****************************

.. automodule:: tests.xmlreader_tests
    :members:
    :undoc-members:
    :show-inheritance:
