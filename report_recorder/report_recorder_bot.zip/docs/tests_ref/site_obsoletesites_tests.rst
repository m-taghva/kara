***************************************
tests.site\_obsoletesites\_tests module
***************************************

.. automodule:: tests.site_obsoletesites_tests
    :members:
    :undoc-members:
    :show-inheritance:
