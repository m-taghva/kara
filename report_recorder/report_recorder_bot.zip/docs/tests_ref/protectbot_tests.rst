******************************
tests.protectbot\_tests module
******************************

.. automodule:: tests.protectbot_tests
    :members:
    :undoc-members:
    :show-inheritance:
