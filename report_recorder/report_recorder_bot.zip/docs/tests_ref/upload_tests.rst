**************************
tests.upload\_tests module
**************************

.. automodule:: tests.upload_tests
    :members:
    :undoc-members:
    :show-inheritance:
