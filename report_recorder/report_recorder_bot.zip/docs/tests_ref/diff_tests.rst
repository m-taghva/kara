************************
tests.diff\_tests module
************************

.. automodule:: tests.diff_tests
    :members:
    :undoc-members:
    :show-inheritance:
