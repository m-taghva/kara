********************************
tests.site\_detect\_tests module
********************************

.. automodule:: tests.site_detect_tests
    :members:
    :undoc-members:
    :show-inheritance:
