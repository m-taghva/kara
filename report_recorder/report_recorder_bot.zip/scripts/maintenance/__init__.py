"""Maintenance scripts.

.. versionchanged:: 8.0
   sorting_order script was removed.
"""
